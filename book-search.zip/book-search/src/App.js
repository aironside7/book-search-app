import React from 'react'
import Bookdiv from './com/Bookdiv'

const App = () => {
  return (
    <>
      <Bookdiv/>
    </>
  )
}

export default App
